﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Linq.Expressions;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Record : Form
    {
        public Record()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form Mainform = Application.OpenForms[0];
            Mainform.Show();
            this.Close();
        }

        private void button1_Leave(object sender, EventArgs e)
        { kapa.BackColor = Color.FromArgb(231, 250, 191); }
        private void button1_Hover(object sender, EventArgs e)
        { kapa.BackColor = Color.FromArgb(4, 160, 255); }

        private void Record_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "school_11ip213DataSet2.Service". При необходимости она может быть перемещена или удалена.
            this.serviceTableAdapter1.Fill(this.school_11ip213DataSet2.Service);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "school_11ip213DataSet.Service". При необходимости она может быть перемещена или удалена.
            this.serviceTableAdapter.Fill(this.school_11ip213DataSet.Service);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "school_11ip213DataSet1.Client". При необходимости она может быть перемещена или удалена.
            this.clientTableAdapter1.Fill(this.school_11ip213DataSet1.Client);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "school_11ip213DataSet.Client". При необходимости она может быть перемещена или удалена.
            this.clientTableAdapter.Fill(this.school_11ip213DataSet.Client);

        }


        /*     int TimeIntSecunds(int a, int b)
             {
              return a * 3600 + b * 60;

         }   */

         public void Lupa(int min, int ch, int sec, TextBox textBox2, TextBox textBox5)
        {
            ch = Convert.ToInt32(textBox3.Text);
            min = Convert.ToInt32(textBox1.Text);
            sec = Convert.ToInt32(textBox4.Text);

            int min1 = min + (sec / 60);
           int ch1 = ch;

            textBox2.Text = Convert.ToString((int)min1);
            textBox5.Text = Convert.ToString((int)ch1);
        }

        public void Pupa(int ch, int sec, int min, TextBox textBox2, TextBox textBox5)
        {
            ch = Convert.ToInt32(textBox3.Text);
            min = Convert.ToInt32(textBox1.Text);
            sec = Convert.ToInt32(textBox4.Text);

            int ch1 = ch + (sec / 3600);
            sec = sec % 3600;
            int min1 = sec / 60;

            textBox2.Text = Convert.ToString((int)min1);
            textBox5.Text = Convert.ToString((int)ch1);
        }
        /* */

        private void EndButton_Click(object sender, EventArgs e)
        {
            /* 
             int ch, min, sec;
             ch = Convert.ToInt32(textBox3.Text);
             min = Convert.ToInt32(textBox1.Text);
             sec = TimeIntSecunds(ch, min);
             int dur = Convert.ToInt32(textBox4.Text);
             sec = sec + dur;
             textBox5.Text = Convert.ToString((int)sec / 3600);
             sec = sec % 3600;
             textBox2.Text = Convert.ToString((int)sec / 60);   
             */

            
            int ch, min, sec;
            ch = Convert.ToInt32(textBox3.Text);
            min = Convert.ToInt32(textBox1.Text);
            sec = Convert.ToInt32(textBox4.Text);

            int pop = ch * 3600 + (min * 60) + sec;
            

            if (sec >= 60 & sec < 3600)
            {
                Lupa(ch, sec, pop, textBox2, textBox5);


            }

            else if (sec >= 3600)
            {
                Pupa(ch, sec, pop, textBox2, textBox5);


            } 
        }
    }
}