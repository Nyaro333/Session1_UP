﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Edit : Form
    {
        public Edit()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form Mainform = Application.OpenForms[0];
            Mainform.Show();
            this.Close();
        }

        private void button1_Leave(object sender, EventArgs e)
        { kapa.BackColor = Color.FromArgb(231, 250, 191); }
        private void button1_Hover(object sender, EventArgs e)
        { kapa.BackColor = Color.FromArgb(4, 160, 255); }

        private void button3_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {

        }
    }
}
