﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "school_11ip213DataSet.Service". При необходимости она может быть перемещена или удалена.
            this.serviceTableAdapter.Fill(this.school_11ip213DataSet.Service);

            EditButton.Enabled = false;
            RecordButton.Enabled = false;
            ViewButton.Enabled = false;

        }

        private void ViewButton_Click(object sender, EventArgs e)
        {
            View View = new View();
            View.Show();
            this.Hide();
        }

        private void RecordButton_Click(object sender, EventArgs e)
        {
            Record Record = new Record();
            Record.Show();
            this.Hide();
        }

        private void EditButton_Click(object sender, EventArgs e)
        {
            Edit Edit = new Edit();
            Edit.Show();
            this.Hide();
        }

        private void kodButton_Click(object sender, EventArgs e)
        {
            if (kodBox.Text == "0000")
            {
                EditButton.Enabled = true;
                RecordButton.Enabled = true;
                ViewButton.Enabled = true;
            }
        }

        private void kodButton_Leave(object sender, EventArgs e)
        { kodButton.BackColor = Color.FromArgb(231, 250, 191); }
        private void EditButton_Leave(object sender, EventArgs e)
        { EditButton.BackColor = Color.FromArgb(231, 250, 191);  }
        private void RecordButton_Leave(object sender, EventArgs e)
        { RecordButton.BackColor = Color.FromArgb(231, 250, 191);  }
        private void ViewButton_Leave(object sender, EventArgs e)
        { ViewButton.BackColor = Color.FromArgb(231, 250, 191);  }

        /* POPKA OGURCHIKA */

        private void kodButton_Hover(object sender, EventArgs e)
        { kodButton.BackColor = Color.FromArgb(4, 160, 255); }
        private void EditButton_Hover(object sender, EventArgs e)
        { EditButton.BackColor = Color.FromArgb(4, 160, 255); }
        private void RecordButton_Hover(object sender, EventArgs e)
        { RecordButton.BackColor = Color.FromArgb(4, 160, 255); }
        private void ViewButton_Hover(object sender, EventArgs e)
        { ViewButton.BackColor = Color.FromArgb(4, 160, 255); }

    }
}
