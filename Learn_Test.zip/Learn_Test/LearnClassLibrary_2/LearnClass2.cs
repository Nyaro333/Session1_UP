﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LearnClassLibrary_2
{
    public class LearnClass2
    {
        public int Lupa(int min, int ch, int sec)
        {

            int min1 = min + (sec / 60);
            int ch1 = ch;
            return (min1 + ch1);

        }

        public int Pupa(int ch, int sec, int min)
        {


            int ch1 = ch + (sec / 3600);
            sec = sec % 3600;
            int min1 = sec / 60;
            return (min1 + ch1);

        }
    }
}
