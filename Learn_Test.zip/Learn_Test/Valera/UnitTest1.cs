﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;

namespace LearnClassLibrary.Tests1
{
    [TestClass]
    public class LearnClassTest1
    {
        [TestMethod]
        public void Test_TimeInSecunds()
        {
            //arrange
            int a = 2;
            int b = 3;
            int expected = 7380;

            //act
            LearnClass c = new LearnClass();
            int actual = c.TimeInSecunds(a, b);

            //assert
            Assert.AreEqual(expected, actual);
        }
    }
}
