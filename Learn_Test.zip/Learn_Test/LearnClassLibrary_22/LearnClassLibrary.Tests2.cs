﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;

namespace LearnClassLibrary_2
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void Test_Lupa()
        {
            //arrange
            int ch = 2;
            int min = 3;
            int sec = 600;
            int expected = 7980;

            //act
            LearnClass2 c = new LearnClass2();
            int actual = c.Lupa(ch, min, sec);

            //assert
            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void Test_Pupa()
        {
            //arrange
            int ch = 2;
            int min = 3;
            int sec = 600;
            int expected = 7980;

            //act
            LearnClass2 c = new LearnClass2();
            int actual = c.Pupa(ch, min, sec);

            //assert
            Assert.AreEqual(expected, actual);
        }
    }
}
