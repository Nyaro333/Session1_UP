﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LearnClassLibrary
{
    public class LearnClass
    {
        public int TimeIntSecunds(int a, int b)
        {
            return a * 3600 + b * 60 + 1;
        }
    }
}
